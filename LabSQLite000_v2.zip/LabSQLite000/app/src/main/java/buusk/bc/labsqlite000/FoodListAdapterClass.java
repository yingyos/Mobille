package buusk.bc.labsqlite000;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class FoodListAdapterClass extends BaseAdapter {
    Context context;
    ArrayList<String> foodID;
    ArrayList<String> foodName;
    ArrayList<String> foodType;

    public FoodListAdapterClass(Context context, ArrayList<String> foodID, ArrayList<String> foodName, ArrayList<String> foodType) {
        this.context = context;
        this.foodID = foodID;
        this.foodName = foodName;
        this.foodType = foodType;
    }


    @Override
    public int getCount() {
        return foodID.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View child, ViewGroup parent) {
        Holder holder;
        LayoutInflater layoutInflater;
        if(child==null){
            layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            child = layoutInflater.inflate(R.layout.lvcolumn,null);

            holder = new Holder();

            holder.textviewid.setText(foodID.get(position));
            holder.textviewname.setText(foodName.get(position));
            holder.textviewphone_number.setText(foodType.get(position));
        }
        return child;
    }


    public class Holder {
        TextView textviewid;
        TextView textviewname;
        TextView textviewphone_number;
    }
}
