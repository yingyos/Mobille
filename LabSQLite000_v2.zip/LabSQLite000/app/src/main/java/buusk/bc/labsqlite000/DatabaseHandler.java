package buusk.bc.labsqlite000;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yingyos on 16/2/2018 AD.
 */

public class DatabaseHandler extends SQLiteOpenHelper {
    private static final int version = 1;
    private static final String name = "contactsManager";

    public DatabaseHandler(Context context) {
        super(context, name, null, version);
    }

    public static final String KEY_ID = "id";
    public static final String KEY_NAME = "name";
    public static final String KEY_PH_NO = "phone_number";

    private static final String TABLE_CONTACTS = "contacts";

    /////////////////////////////////////////////////////////
    //Food
    /////////////////////////////////////////////////////////

    public static final String KEY_FOODID = "fd_id";
    public static final String KEY_FOODNAME = "fd_name";
    public static final String KEY_FOODTYPE = "fd_type";

    private static final String TABLE_FOODS = "foods";
    /////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////
    //Water
    /////////////////////////////////////////////////////////

    public static final String KEY_WATERID = "waterid";
    public static final String KEY_WATERNAME = "watername";
    public static final String KEY_WATERQUALITY = "waterquality";

    private static final String TABLE_WATER = "WATER";
    /////////////////////////////////////////////////////////



    @Override
    public void onCreate(SQLiteDatabase db) {
        //String sqlstring = "CREATE TABLE contacts (id INTEGER PRIMARY KEY, name TEXT,phone_number TEXT)"

        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_CONTACTS + " ("
                + KEY_ID + " INTEGER PRIMARY KEY, " + KEY_NAME + " TEXT, "
                + KEY_PH_NO + " TEXT)";

        String CREATE_FOODS_TABLE = "CREATE TABLE " + TABLE_FOODS + " ("
                + KEY_FOODID + " INTEGER PRIMARY KEY, " + KEY_FOODNAME + " TEXT, "
                + KEY_FOODTYPE + " TEXT)";



        String CREATE_WATERS_TABLE = "CREATE TABLE " + TABLE_WATER + " ("
                + KEY_WATERID + " INTEGER PRIMARY KEY, " + KEY_WATERNAME + " TEXT, "
                + KEY_WATERQUALITY + " INTEGER)";


        db.execSQL(CREATE_CONTACTS_TABLE);
        db.execSQL(CREATE_FOODS_TABLE);
        db.execSQL(CREATE_WATERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FOODS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WATER);
        onCreate(db);
    }

    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     * เราจะ(จง)สร้าง method การดำเนินการเพื่อ
     * เพิ่มข้อมูล          public void addContact(Contact contact){}
     * ดึงข้อมูลระบุ id     public Contact getContact(int id){}
     * ดึงข้อมูลทั้งหมด      public List<Contact> getAllContacts(){}
     * นับจำนวนข้อมูล      public int getContactsCount(){}
     * ปรับปรุงข้อมูล       public int updateContact(Contact contact){}
     * ลบข้อมูล           public void deleteContact(Contact contact){}
     * */
    // Adding new contact เพิ่มข้อมูล
    public void addContact(Contact contact){
        // 1. กำหนดคุณสมบัติด้วย SQLiteDatabase ในการใช้ database อ่าน, เขียน(getWritableDatabase)
        SQLiteDatabase db = this.getWritableDatabase();

        // 2. นำค่าใส่ตัวแปรแบบ ContentValues
        ContentValues values = new ContentValues();

        values.put(KEY_NAME, contact.getName());
        values.put(KEY_PH_NO, contact.getPhone_number());

        // 3. ทำการสั่งเพิ่มข้อมูลด้วย .insert
        db.insert(TABLE_CONTACTS,null,values);
        // 4. ปิด database
        db.close();
    }

    // ดึงข้อมูลระบุ id
    public Contact getContact(int id){
        // 1. กำหนดคุณสมบัติด้วย SQLiteDatabase
        // ในการใช้ database เพื่ออ่านโดยใช้ getReadableDatabase()
        SQLiteDatabase db = this.getReadableDatabase();

        // 1  Yingyos  0816973226
        // 2  Bumbim   5222556793   <-  id = 2
        // 3  Dugdig   0983423456

        // 2. ใช้ Cursor ในการระบุเรคคอร์ด ที่ต้องการ ด้วย query ที่ประกอบด้วย
        //    ชื่อตาราง, คำสั่ง SQL
        Cursor cursor = db.query(TABLE_CONTACTS,
                new String [] {KEY_ID,KEY_NAME,KEY_PH_NO},
                KEY_ID + "=?", new String[]{String.valueOf(id)},
                null,null,null,null);
        if (cursor != null)
            cursor.moveToFirst();
        // 3. เอาค่าข้อมูลที่ cursor อ่านได้มาใส่ contact
        Contact contact = new Contact(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1),cursor.getString(2));
        return contact;
    }

    // ดึงข้อมูลทั้งหมด
    // 1  Yingyos  0816973226
    // 2  Bumbim   5222556793
    // 3  Dugdig   0983423456

    public List<Contact> getAllContacts(){
        // 1. ทำการสร้างตัวแปร array สำหรับเก็บข้อมูลโดยใช้ ArrayList
        List<Contact> contactList = new ArrayList<Contact>();
        // 2. สร้างคำสั่งคิวรี่
        String selectQuery = "SELECT * FROM " + TABLE_CONTACTS;
        // 3. กำหนดคุณสมบัติเพื่อใช้งาน database
        //    ซึ่งจะกำหนดให้เป็นแบบอ่าน เพื่อใช้กับ Cursor เมื่อต้องทำการ move cursor
        SQLiteDatabase db = this.getWritableDatabase();
        // 4. สร้างตัวแปร Cursor เพื่อจะใช้ระบุการอ่านแต่ละเรคคอร์ดในตาราง
        Cursor cursor = db.rawQuery(selectQuery,null);

        if(cursor.moveToFirst()){
         // 5. ทำการอ่านค่าแต่ละเรคคอร์ดด้วย cursor และนำเข้าตัวแปร contactList
            do {
                Contact contact = new Contact();
                contact.setId(Integer.parseInt(cursor.getString(0)));
                contact.setName(cursor.getString(1));
                contact.setPhone_number(cursor.getString(2));

                contactList.add(contact);
            }while(cursor.moveToNext());
        }


        return contactList;
    }

    //นับจำนวนข้อมูล
    public int getContactsCount(){
        String countQuery = "SELECT * FROM " + TABLE_CONTACTS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery,null);
        db.close();
        return cursor.getCount();
    }

    //* ปรับปรุงข้อมูล
    public int updateContact(Contact contact){
        SQLiteDatabase db = this.getWritableDatabase();
        // เตรียมข้อมูลที่เราจะทำการแก้ไข
        ContentValues values = new ContentValues();
        values.put(KEY_NAME,contact.getName());
        values.put(KEY_PH_NO,contact.getPhone_number());

        return db.update(TABLE_CONTACTS,values, KEY_ID+ " = ?",
                new String[]{String.valueOf(contact.getId()) });
    }

    //ลบข้อมูล
    public void deleteContact(Contact contact){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CONTACTS,KEY_ID + " = ?",
                new String[]{String.valueOf(contact.getId()) });
    }


    /////////////////////
    //Food//

    // Adding new contact เพิ่มข้อมูล
    public void addFood(Food food){
        // 1. กำหนดคุณสมบัติด้วย SQLiteDatabase ในการใช้ database อ่าน, เขียน(getWritableDatabase)
        SQLiteDatabase db = this.getWritableDatabase();

        // 2. นำค่าใส่ตัวแปรแบบ ContentValues
        ContentValues values = new ContentValues();

        values.put(KEY_FOODNAME, food.getFood_name());
        values.put(KEY_FOODTYPE, food.getFood_type());

        // 3. ทำการสั่งเพิ่มข้อมูลด้วย .insert
        db.insert(TABLE_FOODS,null,values);
        // 4. ปิด database
        db.close();
    }

    // ดึงข้อมูลระบุ id
    public Food getFood(int id){
        // 1. กำหนดคุณสมบัติด้วย SQLiteDatabase
        // ในการใช้ database เพื่ออ่านโดยใช้ getReadableDatabase()
        SQLiteDatabase db = this.getReadableDatabase();

        // 1  Yingyos  0816973226
        // 2  Bumbim   5222556793   <-  id = 2
        // 3  Dugdig   0983423456

        // 2. ใช้ Cursor ในการระบุเรคคอร์ด ที่ต้องการ ด้วย query ที่ประกอบด้วย
        //    ชื่อตาราง, คำสั่ง SQL
        Cursor cursor = db.query(TABLE_FOODS,
                new String [] {KEY_FOODID,KEY_FOODNAME,KEY_FOODTYPE},
                KEY_FOODID + "=?", new String[]{String.valueOf(id)},
                null,null,null,null);
        if (cursor != null)
            cursor.moveToFirst();
        // 3. เอาค่าข้อมูลที่ cursor อ่านได้มาใส่ contact
        Food food = new Food(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1),cursor.getString(2));
        return food;
    }

    // ดึงข้อมูลทั้งหมด
    // 1  Yingyos  0816973226
    // 2  Bumbim   5222556793
    // 3  Dugdig   0983423456

    public List<Food> getAllFoods(){
        // 1. ทำการสร้างตัวแปร array สำหรับเก็บข้อมูลโดยใช้ ArrayList
        List<Food> foodList = new ArrayList<Food>();
        // 2. สร้างคำสั่งคิวรี่
        String selectQuery = "SELECT * FROM " + TABLE_FOODS;
        // 3. กำหนดคุณสมบัติเพื่อใช้งาน database
        //    ซึ่งจะกำหนดให้เป็นแบบอ่าน เพื่อใช้กับ Cursor เมื่อต้องทำการ move cursor
        SQLiteDatabase db = this.getWritableDatabase();
        // 4. สร้างตัวแปร Cursor เพื่อจะใช้ระบุการอ่านแต่ละเรคคอร์ดในตาราง
        Cursor cursor = db.rawQuery(selectQuery,null);

        if(cursor.moveToFirst()){
            // 5. ทำการอ่านค่าแต่ละเรคคอร์ดด้วย cursor และนำเข้าตัวแปร contactList
            do {
                Food food = new Food();
                food.setFood_id(Integer.parseInt(cursor.getString(0)));
                food.setFood_name(cursor.getString(1));
                food.setFood_type(cursor.getString(2));

                foodList.add(food);
            }while(cursor.moveToNext());
        }


        return foodList;
    }

    //นับจำนวนข้อมูล
    public int getFoodsCount(){
        String countQuery = "SELECT * FROM " + TABLE_FOODS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery,null);
        db.close();
        return cursor.getCount();
    }

    //* ปรับปรุงข้อมูล
    public int updateFood(Food food){
        SQLiteDatabase db = this.getWritableDatabase();
        // เตรียมข้อมูลที่เราจะทำการแก้ไข
        ContentValues values = new ContentValues();
        values.put(KEY_FOODNAME,food.getFood_name());
        values.put(KEY_FOODTYPE,food.getFood_name());

        return db.update(TABLE_FOODS,values, KEY_FOODID+ " = ?",
                new String[]{String.valueOf(food.getFood_id()) });
    }

    //ลบข้อมูล
    public void deleteFood(Food food){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_FOODS,KEY_FOODID + " = ?",
                new String[]{String.valueOf(food.getFood_id()) });
    }
    ////////////////////




    //////////////////////
    //Water
    ///////////////////

    public void addWater(Water water){
        // 1. กำหนดคุณสมบัติด้วย SQLiteDatabase ในการใช้ database อ่าน, เขียน(getWritableDatabase)
        SQLiteDatabase db = this.getWritableDatabase();

        // 2. นำค่าใส่ตัวแปรแบบ ContentValues
        ContentValues values = new ContentValues();

        values.put(KEY_WATERNAME, water.getWater_brand());
        values.put(KEY_WATERQUALITY, water.getWater_quality());

        // 3. ทำการสั่งเพิ่มข้อมูลด้วย .insert
        db.insert(TABLE_CONTACTS,null,values);
        // 4. ปิด database
        db.close();
    }

    // ดึงข้อมูลระบุ id
    public Water getWater(int id){
        // 1. กำหนดคุณสมบัติด้วย SQLiteDatabase
        // ในการใช้ database เพื่ออ่านโดยใช้ getReadableDatabase()
        SQLiteDatabase db = this.getReadableDatabase();

        // 1  Yingyos  0816973226
        // 2  Bumbim   5222556793   <-  id = 2
        // 3  Dugdig   0983423456

        // 2. ใช้ Cursor ในการระบุเรคคอร์ด ที่ต้องการ ด้วย query ที่ประกอบด้วย
        //    ชื่อตาราง, คำสั่ง SQL
        Cursor cursor = db.query(TABLE_WATER,
                new String [] {KEY_WATERID,KEY_WATERNAME,KEY_WATERQUALITY},
                KEY_WATERID + "=?", new String[]{String.valueOf(id)},
                null,null,null,null);
        if (cursor != null)
            cursor.moveToFirst();
        // 3. เอาค่าข้อมูลที่ cursor อ่านได้มาใส่ contact
        Water water = new Water(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1),cursor.getInt(2));
        return water;
    }

    // ดึงข้อมูลทั้งหมด
    // 1  Yingyos  0816973226
    // 2  Bumbim   5222556793
    // 3  Dugdig   0983423456

    public List<Water> getAllWater(){
        // 1. ทำการสร้างตัวแปร array สำหรับเก็บข้อมูลโดยใช้ ArrayList
        List<Water> waterList = new ArrayList<Water>();
        // 2. สร้างคำสั่งคิวรี่
        String selectQuery = "SELECT * FROM " + TABLE_WATER;
        // 3. กำหนดคุณสมบัติเพื่อใช้งาน database
        //    ซึ่งจะกำหนดให้เป็นแบบอ่าน เพื่อใช้กับ Cursor เมื่อต้องทำการ move cursor
        SQLiteDatabase db = this.getWritableDatabase();
        // 4. สร้างตัวแปร Cursor เพื่อจะใช้ระบุการอ่านแต่ละเรคคอร์ดในตาราง
        Cursor cursor = db.rawQuery(selectQuery,null);

        if(cursor.moveToFirst()){
            // 5. ทำการอ่านค่าแต่ละเรคคอร์ดด้วย cursor และนำเข้าตัวแปร contactList
            do {
                Water water = new Water();
                water.setWater_id(Integer.parseInt(cursor.getString(0)));
                water.setWater_brand(cursor.getString(1));
                water.setWater_quality(cursor.getInt(2));

                waterList.add(water);
            }while(cursor.moveToNext());
        }


        return waterList;
    }

    //นับจำนวนข้อมูล
    public int getWaterCount(){
        String countQuery = "SELECT * FROM " + TABLE_WATER;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery,null);
        db.close();
        return cursor.getCount();
    }

    //* ปรับปรุงข้อมูล
    public int updateWater(Water water){
        SQLiteDatabase db = this.getWritableDatabase();
        // เตรียมข้อมูลที่เราจะทำการแก้ไข
        ContentValues values = new ContentValues();
        values.put(KEY_WATERNAME,water.getWater_brand());
        values.put(KEY_WATERQUALITY,water.getWater_quality());

        return db.update(TABLE_WATER,values, KEY_WATERID+ " = ?",
                new String[]{String.valueOf(water.getWater_id()) });
    }

    //ลบข้อมูล
    public void deleteWater(Water water){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WATER,KEY_WATERID + " = ?",
                new String[]{String.valueOf(water.getWater_id()) });
    }
}
