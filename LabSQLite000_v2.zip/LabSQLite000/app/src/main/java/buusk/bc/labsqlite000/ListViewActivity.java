package buusk.bc.labsqlite000;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by yingyos on 2/3/2018 AD.
 */

public class ListViewActivity extends Activity {
    DatabaseHandler SQLITEHELPER;
    SQLiteDatabase SQLITEDATABASE;
    Cursor cursor;
    ListView LISTVIEW;

    ListAdapterClass ListAdapter;

    ArrayList<String> ID_ArrayList = new ArrayList<String>();
    ArrayList<String> NAME_ArrayList = new ArrayList<String>();
    ArrayList<String> PHONE_NUMBER_ArrayList = new ArrayList<String>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.listview1);
        LISTVIEW = (ListView) findViewById(R.id.lv1);
        SQLITEHELPER = new DatabaseHandler(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ShowSQLiteDBdata();
    }

    private void ShowSQLiteDBdata(){
        SQLITEDATABASE = SQLITEHELPER.getWritableDatabase();
        cursor = SQLITEDATABASE.rawQuery("SELECT * FROM contacts",null);

        ID_ArrayList.clear();
        NAME_ArrayList.clear();
        PHONE_NUMBER_ArrayList.clear();

        if(cursor.moveToFirst()){
            do{
                ID_ArrayList.add(cursor.getString(
                        cursor.getColumnIndex(DatabaseHandler.KEY_ID)));
                NAME_ArrayList.add(cursor.getString(
                        cursor.getColumnIndex(DatabaseHandler.KEY_NAME)));
                PHONE_NUMBER_ArrayList.add(cursor.getString(
                        cursor.getColumnIndex(DatabaseHandler.KEY_PH_NO)));
            }while (cursor.moveToNext());

            ListAdapter = new ListAdapterClass(ListViewActivity.this,ID_ArrayList,NAME_ArrayList,PHONE_NUMBER_ArrayList);
            LISTVIEW.setAdapter(ListAdapter);

            cursor.close();
        }
    }
}
