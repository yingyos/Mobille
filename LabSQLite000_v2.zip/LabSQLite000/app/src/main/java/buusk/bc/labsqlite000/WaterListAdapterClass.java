package buusk.bc.labsqlite000;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class WaterListAdapterClass extends BaseAdapter {
    Context context;
    ArrayList<String> waterID;
    ArrayList<String> waterName;
    ArrayList<String> waterQuality;

    public WaterListAdapterClass(Context context, ArrayList<String> waterID, ArrayList<String> waterName, ArrayList<String> waterQuality) {
        this.context = context;
        this.waterID = waterID;
        this.waterName = waterName;
        this.waterQuality = waterQuality;
    }

    @Override
    public int getCount() {
        return waterID.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View child, ViewGroup parent) {
        Holder holder;
        LayoutInflater layoutInflater;
        if(child==null){
            layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            child = layoutInflater.inflate(R.layout.lvcolumn,null);

            holder = new Holder();

            holder.textviewid.setText(waterID.get(position));
            holder.textviewname.setText(waterName.get(position));
            holder.textviewphone_number.setText(waterQuality.get(position));
        }
        return child;
    }


    public class Holder {
        TextView textviewid;
        TextView textviewname;
        TextView textviewphone_number;
    }
}
