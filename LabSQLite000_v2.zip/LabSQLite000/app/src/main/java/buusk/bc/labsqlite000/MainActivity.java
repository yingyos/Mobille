package buusk.bc.labsqlite000;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView ContactListView;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,
                        FoodListViewActivity.class);
                startActivity(intent);
            }
        });


        // add
        DatabaseHandler db = new DatabaseHandler(this);
        Log.d("Yingyos Insert: ","Inserting ... ");

        db.addFood(new Food(1,"Yingyos","58410000"));
        //db.addContact(new Contact("Student1","58410001"));
        //db.addContact(new Contact("Student2","58410002"));
        //db.addContact(new Contact("Student3","58410003"));

        // read all
        Log.d("Yingyos Reading:", "Reading all contacts..");
        List<Contact> contacts = db.getAllContacts();

        for (Contact cn : contacts){
            String log = "Id: " + cn.getId()+" ,Name: " +
                    cn.getName() + " ,Phone: " +
                    cn.getPhone_number();
            Log.d("Name: ", log);
        }

        // read all Food
        Log.d("Food Reading:", "Reading all foods..");
        List<Food> foods = db.getAllFoods();

        for (Food cn : foods){
            String log = "Id: " + cn.getFood_id()+" ,Name: " +
                    cn.getFood_name() + " ,TYPE: " +
                    cn.getFood_type();
            Log.d("Name: ", log);
        }





    }




}
