package buusk.bc.labsqlite000;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.ListView;

import java.util.ArrayList;

public class FoodListViewActivity extends Activity{

    DatabaseHandler SQLITEHELPER;
    SQLiteDatabase SQLITEDATABASE;
    Cursor cursor;
    ListView LISTVIEW;

    FoodListAdapterClass FoodListAdapter;

    ArrayList<String> FOODID_ArrayList = new ArrayList<String>();
    ArrayList<String> FOODNAME_ArrayList = new ArrayList<String>();
    ArrayList<String> FOODTYPE_ArrayList = new ArrayList<String>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.foodviewactivity);
        LISTVIEW = (ListView) findViewById(R.id.foodlv);
        SQLITEHELPER = new DatabaseHandler(this);
    }
    @Override
    protected void onResume() {
        super.onResume();
        ShowSQLiteDBdata();
    }

    private void ShowSQLiteDBdata(){
        SQLITEDATABASE = SQLITEHELPER.getWritableDatabase();
        cursor = SQLITEDATABASE.rawQuery("SELECT * FROM foods",null);

        FOODID_ArrayList.clear();
        FOODNAME_ArrayList.clear();
        FOODTYPE_ArrayList.clear();

        if(cursor.moveToFirst()){
            do{
                FOODID_ArrayList.add(cursor.getString(
                        cursor.getColumnIndex(DatabaseHandler.KEY_FOODID)));
                FOODNAME_ArrayList.add(cursor.getString(
                        cursor.getColumnIndex(DatabaseHandler.KEY_FOODNAME)));
                FOODTYPE_ArrayList.add(cursor.getString(
                        cursor.getColumnIndex(DatabaseHandler.KEY_FOODTYPE)));
            }while (cursor.moveToNext());

            FoodListAdapter = new FoodListAdapterClass(FoodListViewActivity.this,FOODID_ArrayList,FOODNAME_ArrayList,FOODTYPE_ArrayList);
            LISTVIEW.setAdapter(FoodListAdapter);

            cursor.close();
        }
    }
}
