package buusk.bc.labsqlite000;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by yingyos on 16/3/2018 AD.
 */

class ListAdapterClass extends BaseAdapter{
    Context context;
    ArrayList<String> uID;
    ArrayList<String> uName;
    ArrayList<String> uPhoneNumber;

    public ListAdapterClass(Context context, ArrayList<String> uID, ArrayList<String> uName, ArrayList<String> uPhoneNumber) {
        this.context = context;
        this.uID = uID;
        this.uName = uName;
        this.uPhoneNumber = uPhoneNumber;
    }


    @Override
    public int getCount() {
        return uID.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View child, ViewGroup parent) {
        Holder holder;
        LayoutInflater layoutInflater;
        if(child==null){
            layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            child = layoutInflater.inflate(R.layout.lvcolumn,null);

            holder = new Holder();

            holder.textviewid.setText(uID.get(position));
            holder.textviewname.setText(uName.get(position));
            holder.textviewphone_number.setText(uPhoneNumber.get(position));
        }
        return child;
    }


    public class Holder {
        TextView textviewid;
        TextView textviewname;
        TextView textviewphone_number;
    }
}
