package buusk.bc.labsqlite000;

public class Water {
    public int getWater_id() {
        return water_id;
    }

    public void setWater_id(int water_id) {
        this.water_id = water_id;
    }

    public String getWater_brand() {
        return water_brand;
    }

    public void setWater_brand(String water_brand) {
        this.water_brand = water_brand;
    }

    public int getWater_quality() {
        return water_quality;
    }

    public void setWater_quality(int water_quality) {
        this.water_quality = water_quality;
    }

    int water_id;
    String water_brand;
    int water_quality;

    public Water(int water_id, String water_brand, int water_quality) {
        this.water_id = water_id;
        this.water_brand = water_brand;
        this.water_quality = water_quality;
    }

    public Water(){}
}
