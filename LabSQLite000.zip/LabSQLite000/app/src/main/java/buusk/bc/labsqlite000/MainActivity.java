package buusk.bc.labsqlite000;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView ContactListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ContactListView = (ListView) findViewById(R.id.lv1);

        // add
        DatabaseHandler db = new DatabaseHandler(this);
        Log.d("Yingyos Insert: ","Inserting ... ");

        //db.addContact(new Contact("Yingyos","58410000"));
        //db.addContact(new Contact("Student1","58410001"));
        //db.addContact(new Contact("Student2","58410002"));
        //db.addContact(new Contact("Student3","58410003"));

        // read all
        Log.d("Yingyos Reading:", "Reading all contacts..");
        List<Contact> contacts = db.getAllContacts();

        for (Contact cn : contacts){
            String log = "Id: " + cn.getId()+" ,Name: " +
                    cn.getName() + " ,Phone: " +
                    cn.getPhone_number();
            Log.d("Name: ", log);

        }




    }




}
